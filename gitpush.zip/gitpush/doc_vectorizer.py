import os
from typing import List, Dict
from chromadb import Client, Settings
from chromadb.utils import embedding_functions
from transformers import pipeline
from sentence_transformers import SentenceTransformer, CrossEncoder
from unstructured.partition.auto import partition
from langchain.text_splitter import RecursiveCharacterTextSplitter

class DocVectorizer:
    def clear_database(self):
        import shutil, os
        self.client.delete_collection(name=self.collection.name)
        self.collection = self.client.get_or_create_collection(name=self.collection.name, embedding_function=self.embedding_function)
        # Also clear markdown_outputs folder
        md_folder = os.path.join(os.path.dirname(__file__), "markdown_outputs")
        if os.path.exists(md_folder):
            shutil.rmtree(md_folder)
        os.makedirs(md_folder, exist_ok=True)
        print("DEBUG: Vector database and markdown_outputs cleared.")

    def __init__(self, db_path: str = "new_doc/chroma_db", collection_name: str = "documents"):
        self.client = Client(Settings(persist_directory=db_path, is_persistent=True))
        self.embedding_function = embedding_functions.SentenceTransformerEmbeddingFunction(model_name="all-MiniLM-L6-v2")
        self.collection = self.client.get_or_create_collection(name=collection_name, embedding_function=self.embedding_function)
        # RAG Model Summary Table
        # | Task            | Best Model (Open, Small, CPU)                |
        # |-----------------|---------------------------------------------|
        # | Extractive QA   | deepset/roberta-base-squad2                 |
        # | Re-ranking      | cross-encoder/ms-marco-TinyBERT-L-2-v2      |
        # | Paraphrase/LLM  | microsoft/phi-2                             |
        self.qa_pipeline = pipeline("question-answering", model="deepset/roberta-base-squad2")
        self.ner_pipeline = pipeline("ner", model="dslim/bert-base-NER", aggregation_strategy="simple")
        self.cross_encoder = CrossEncoder('cross-encoder/ms-marco-TinyBERT-L-2-v2', max_length=512)
        self.generator_pipeline = pipeline("text-generation", model="microsoft/phi-2", torch_dtype="auto", trust_remote_code=True)

    def _classify_doc_type(self, text: str) -> str:
        text_lower = text.lower()
        resume_keywords = ['experience', 'education', 'skills', 'summary', 'objective', 'work history', 'employment']
        hr_keywords = ['human resources', 'policy', 'employee handbook', 'confidentiality', 'code of conduct', 'benefits']
        process_keywords = ['procedure', 'workflow', 'step-by-step', 'guideline', 'process flow', 'standard operating procedure']
        kt_keywords = ['knowledge transfer', 'kt session', 'handover', 'transition', 'project details']
        if sum(1 for keyword in resume_keywords if keyword in text_lower) >= 3:
            return 'resume'
        if sum(1 for keyword in hr_keywords if keyword in text_lower) >= 2:
            return 'hr_policy'
        if sum(1 for keyword in process_keywords if keyword in text_lower) >= 2:
            return 'process_document'
        if sum(1 for keyword in kt_keywords if keyword in text_lower) >= 2:
            return 'kt_document'
        return 'general'


    def fine_grained_chunking(self, md_text):
        import re
        # Universal split: step numbers, bullets, and resume/KT patterns ANYWHERE in the text
        pattern = r'(\n\d+\.\s+|\n[\-\*•]\s+|Customer name:|Roles?:|Person repayment status|Email id:|Phone number:|^\d+\.\s+|^[\-\*•]\s+)'
        # Add a newline at the start to ensure the first match is found
        text = '\n' + md_text.strip()
        matches = list(re.finditer(pattern, text, re.MULTILINE))
        starts = [m.start() for m in matches] + [len(text)]
        chunks = []
        for i in range(len(starts)-1):
            chunk = text[starts[i]:starts[i+1]].strip()
            if chunk:
                chunks.append(chunk)
        # Fallback for docs without structure
        if not chunks:
            lines = md_text.splitlines()
            avg_len = sum(len(line) for line in lines) / (len(lines) or 1)
            chunk_size = 1000 if avg_len < 80 else 500
            chunk = []
            curr_len = 0
            for line in lines:
                chunk.append(line)
                curr_len += len(line)
                if curr_len > chunk_size:
                    chunks.append('\n'.join(chunk))
                    chunk = []
                    curr_len = 0
            if chunk:
                chunks.append('\n'.join(chunk))
        return chunks

# Replace all calls to adaptive_markdown_chunking with fine_grained_chunking in add_document

    def add_document(self, file_path: str, doc_type: str = None) -> dict:
        import os
        source_filename = os.path.basename(file_path)
        elements = partition(file_path)
        markdown_text = []
        for el in elements:
            markdown_text.append(el.text)
        md_text = "\n".join(markdown_text)
        # Post-process: ensure each numbered step or bullet starts on a new line
        import re
        md_text = re.sub(r'(?<!\n)(\d+\.\s+)', r'\n\1', md_text)
        md_text = re.sub(r'(?<!\n)([\-\*•]\s+)', r'\n\1', md_text)
        # Save markdown output
        md_folder = os.path.join(os.path.dirname(__file__), "markdown_outputs")
        os.makedirs(md_folder, exist_ok=True)
        md_path = os.path.join(md_folder, source_filename + ".md")
        with open(md_path, "w", encoding="utf-8") as f:
            f.write(md_text)
        # Fine-grained chunking
        chunks = self.fine_grained_chunking(md_text)
        print(f"DEBUG: Chunk texts after splitting:")
        for idx, chunk in enumerate(chunks):
            print(f"Chunk {idx+1}:\n{chunk}\n{'-'*40}")
        doc_ids = [source_filename + f"_{i}" for i in range(len(chunks))]
        metadatas = []
        final_doc_type = doc_type or self._classify_doc_type(md_text)
        print(f"DEBUG: Chunks created for {source_filename} (type: {final_doc_type}):")
        from dateutil import parser
        from datetime import datetime
        import re
        def extract_years_of_experience(text):
            # Example pattern: Sep 2021 – Present or Sep 2021 – till now
            matches = re.findall(r'([A-Za-z]{3,9} \d{4})\s*[–-]\s*([A-Za-z]{3,9} \d{4}|Present|till now)', text, re.IGNORECASE)
            total_months = 0
            for start, end in matches:
                try:
                    start_date = parser.parse(start)
                    if end.lower() in ['present', 'till now']:
                        end_date = datetime.now()
                    else:
                        end_date = parser.parse(end)
                    diff = (end_date.year - start_date.year) * 12 + (end_date.month - start_date.month)
                    total_months += max(diff, 0)
                except Exception:
                    continue
            return round(total_months / 12, 1) if total_months else None

        # Local spaCy+regex resume field extraction (no pyresparser)
        ats_data = None
        def extract_resume_fields(text):
            import spacy, re
            from datetime import datetime
            from dateutil import parser

            nlp = spacy.load("en_core_web_sm")
            doc = nlp(text)

            # 1. Improved Name Extraction: Find the longest name at the top of the resume
            name = None
            doc_top_part = nlp(text[:int(len(text) * 0.2)]) # Analyze top 20% of the doc
            person_entities = [ent.text.split('\n')[0].strip() for ent in doc_top_part.ents if ent.label_ == "PERSON"]
            if person_entities:
                name = max(person_entities, key=len)
            else: # Fallback to first person entity in the whole doc
                for ent in doc.ents:
                    if ent.label_ == "PERSON":
                        name = ent.text.split('\n')[0].strip()
                        break

            # 2. Improved Email Extraction
            email_match = re.search(r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}', text)
            email = email_match.group(0) if email_match else None

            phone = re.search(r"\+?\d[\d\s-]{8,}\d", text)

            # 3. Improved Experience Calculation
            total_experience = None
            # Regex for formats like 'Feb 2019 to Till' or '2019-2022'
            date_ranges = re.findall(r"([A-Za-z]{3,9}[\s,]+\d{4})\s*(?:to|–|-)\s*([A-Za-z]{3,9}[\s,]+\d{4}|Present|till now|Till)", text, re.IGNORECASE)
            total_months = 0
            if date_ranges:
                for start, end in date_ranges:
                    try:
                        start_date = parser.parse(start)
                        if end.lower() in ['present', 'till now', 'till']:
                            end_date = datetime.now()
                        else:
                            end_date = parser.parse(end)
                        diff = (end_date.year - start_date.year) * 12 + (end_date.month - start_date.month)
                        total_months += max(diff, 0)
                    except Exception:
                        continue
                if total_months > 0:
                    total_experience = round(total_months / 12, 1)
            
            # Fallback 1: Look for year-only ranges like '2019-2022' or '2019 - Present'
            if not total_experience:
                year_ranges = re.findall(r"(\d{4})\s*(?:to|–|-)\s*(\d{4}|Present|Current|Till)", text, re.IGNORECASE)
                if year_ranges:
                    for start_year, end_year in year_ranges:
                        try:
                            start_date = datetime(int(start_year), 1, 1)
                            if end_year.lower() in ['present', 'current', 'till']:
                                end_date = datetime.now()
                            else:
                                end_date = datetime(int(end_year), 12, 31)
                            diff = (end_date.year - start_date.year) * 12 + (end_date.month - start_date.month)
                            total_months += max(diff, 0)
                        except Exception:
                            continue
                    if total_months > 0:
                        total_experience = round(total_months / 12, 1)

            # Fallback 2: Look for phrases like '6+ years of experience'
            if not total_experience:
                exp_phrase = re.search(r"(\d+\+?)\s+years? of experience", text, re.I)
                if exp_phrase:
                    total_experience = int(re.sub(r'\D', '', exp_phrase.group(1)))

            # Fallback 3: Look for phrases like 'Total Experience: 5 years'
            if not total_experience:
                exp_phrase = re.search(r"total experience\s*:\s*(\d+\.?\d*)\s*years?", text, re.I)
                if exp_phrase:
                    total_experience = float(exp_phrase.group(1))

            # Skills extraction (simple match from list)
            SKILLS = [
                'python', 'java', 'sql', 'c++', 'machine learning', 'deep learning', 'nlp', 'pandas', 'numpy',
                'scikit-learn', 'tensorflow', 'keras', 'docker', 'git', 'azure', 'gcp', 'aws', 'linux', 'excel',
                'power bi', 'tableau', 'data analysis', 'data visualization', 'spark', 'hadoop', 'r', 'matplotlib',
                'langchain', 'transformers', 'faiss', 'mlflow', 'autokeras', 'opencv', 'pytorch', 'spacy', 'nltk'
            ]
            found_skills = set()
            for skill in SKILLS:
                if re.search(rf'\b{re.escape(skill)}\b', text, re.I):
                    found_skills.add(skill)

            # Degree extraction
            DEGREE_KEYWORDS = [
                'b.e', 'btech', 'bachelor', 'm.e', 'mtech', 'master', 'phd', 'doctor', 'msc', 'bsc', 'mba', 'bca', 'mca', 'bcom', 'mcom'
            ]
            found_degrees = set()
            for degree in DEGREE_KEYWORDS:
                if re.search(rf'\b{re.escape(degree)}\b', text, re.I):
                    found_degrees.add(degree)

            # 4. Cleaned-up Location Extraction
            locations = set()
            location_blocklist = {'project', 'rest', 'api', 'index', 'postgresql', 'chennai', 'namakkal'}
            for ent in doc.ents:
                if ent.label_ == "GPE":
                    if ent.text.lower() not in location_blocklist:
                        locations.add(ent.text)

            return {
                "name": name,
                "email": email,
                "phone": phone.group(0) if phone else None,
                "total_experience": total_experience,
                "skills": list(found_skills),
                "degrees": list(found_degrees),
                "locations": list(locations)
            }
        # Only run for resumes
        if file_path.lower().endswith(('.pdf', '.docx')):
            try:
                # Extract text using your existing logic
                ext = os.path.splitext(file_path)[1]
                text = ''
                if ext == '.pdf':
                    from pdfplumber import open as pdfopen
                    with pdfopen(file_path) as pdf:
                        text = "\n".join(page.extract_text() or '' for page in pdf.pages)
                elif ext == '.docx':
                    import docx2txt
                    text = docx2txt.process(file_path)
                ats_data = extract_resume_fields(text)
                print(f"ATS Extracted (spaCy/regex): {ats_data}")
            except Exception as e:
                print(f"ATS extraction failed: {e}")
        metadatas = []
        doc_ids = [f"{source_filename}_{i}" for i in range(len(chunks))]

        for idx, chunk in enumerate(chunks):
            entities = self.ner_pipeline(chunk)
            persons = ",".join(sorted(set([e['word'].lower() for e in entities if e['entity_group'] == 'PER'])))
            # Extract section title and step/bullet header
            section_title = ""
            step_header = ""
            lines = chunk.split('\n')
            if lines and lines[0].startswith('#'):
                section_title = lines[0]
                if len(lines) > 1 and (re.match(r'\d+\.', lines[1]) or re.match(r'[\-\*•]', lines[1])):
                    step_header = lines[1]
            
            # Experience extraction
            exp_years = extract_years_of_experience(chunk)
            meta = {"source": source_filename, "persons": persons, "doc_type": final_doc_type, "section_title": section_title, "step_header": step_header}
            if exp_years:
                meta["total_experience_years"] = exp_years

            # Add ATS fields to metadata if available
            if ats_data:
                for k, v in ats_data.items():
                    if v:
                        # Convert lists to comma-separated strings for ChromaDB
                        if isinstance(v, list):
                            meta[f'ats_{k}'] = ', '.join(map(str, v))
                        else:
                            meta[f'ats_{k}'] = v
            
            print(f"Chunk {idx+1}:\n{chunk[:200]}...\nMeta: {meta}\n{'-'*50}")
            metadatas.append(meta)
        
        self.collection.add(documents=chunks, metadatas=metadatas, ids=doc_ids)
        return {"doc_ids": doc_ids, "chunks": [{"text": c, "meta": m} for c, m in zip(chunks, metadatas)]}
    def search(self, query: str, n_results: int = 5, temperature: float = 0.1, model_type: str = 'qa', doc_type: str = None) -> List[Dict]:
        import re
        ner_results = self.ner_pipeline(query)
        query_persons = [e['word'].lower() for e in ner_results if e['entity_group'] == 'PER']
        where_filter = {}
        if doc_type and doc_type != 'all':
            where_filter['doc_type'] = doc_type
        if query_persons:
            # Prioritize filtering by ats_name if available, otherwise fallback to chunk-level persons
            where_filter = {
                "$or": [
                    {"ats_name": {"$in": query_persons}},
                    {"persons": {"$in": query_persons}}
                ]
            }
        if where_filter:
            results = self.collection.query(query_texts=[query], n_results=n_results, where=where_filter)
        else:
            results = self.collection.query(query_texts=[query], n_results=n_results)

        # Print all candidate chunks
        print("DEBUG: Candidate chunks from vector store:")
        for idx, (chunk, meta) in enumerate(zip(results['documents'][0], results['metadatas'][0])):
            print(f"Candidate {idx+1}:\n{chunk[:200]}...\nMeta: {meta}\n{'-'*50}")

        # Post-process for experience queries if needed
        exp_query = re.search(r'(years?|total) of experience|work experience|who has more experience', query, re.I)
        # Check if we got any results before proceeding
        if not results or not results.get('metadatas') or not results['metadatas'][0]:
            return [{
                "answer": "No relevant documents found for your query.",
                "qa_answer": "",
                "llm_answer": "",
                "context": "",
                "chunks": [],
                "matched_chunks": []
            }]

        if exp_query and results['metadatas']:
            # Get the experience from the top-ranked candidate's metadata
            top_candidate_meta = results['metadatas'][0][0]
            exp = top_candidate_meta.get('ats_total_experience')
            name = top_candidate_meta.get('ats_name', 'Candidate')
            if exp is not None:
                answer = f"{name} has {exp} years of experience."
                return [{
                    "answer": answer,
                    "qa_answer": answer,
                    "llm_answer": answer,
                    "context": str(top_candidate_meta),
                    "chunks": [],
                    "matched_chunks": []
                }]
        # Strict dynamic filtering: only keep chunks where PERSON entity matches exactly
        matched_chunks = []
        matched_debug = []
        if query_persons:
            for chunk, meta in zip(results['documents'][0], results['metadatas'][0]):
                persons = [p.strip() for p in meta.get('persons', '').split(',') if p.strip()]
                if any(qp == p for qp in query_persons for p in persons):
                    matched_chunks.append(chunk)
                    matched_debug.append({'chunk': chunk, 'persons': persons})
            if matched_chunks:
                print(f"DEBUG: Strict entity filter matched chunks: {matched_debug}")
                context = "\n---\n".join(matched_chunks)
            else:
                print(f"DEBUG: No chunks matched strict entity filter for persons {query_persons}")
                return [{"answer": f"No relevant information found for {'/'.join(query_persons)}.", "context": "", "chunks": results['documents'][0][:3], "matched_chunks": []}]
        else:
            context = "\n---\n".join(results['documents'][0])
        # Safe-guard: if context is empty, return a graceful answer
        if not context.strip():
            return [{
                "answer": "Not found in documents.",
                "qa_answer": None,
                "llm_answer": None,
                "context": "",
                "chunks": [],
                "matched_chunks": []
            }]
        qa_answer = ""
        llm_answer = ""

        # 1. Attempt Factual QA first
        qa_result = self.qa_pipeline(question=query, context=context)
        if qa_result['score'] > 0.1: # Confidence threshold
            qa_answer = qa_result['answer']

        # 2. If Factual QA fails or user selected LLM, use the LLM as a fallback/primary
        if not qa_answer or model_type == 'llm':
            if self.generator_pipeline:
                prompt = f"Based on the following context, answer the question.\n\nContext:\n{context}\n\nQuestion: {query}\n\nAnswer:"
                try:
                    llm_result = self.generator_pipeline(prompt, max_length=150, num_return_sequences=1, pad_token_id=self.generator_pipeline.tokenizer.eos_token_id)
                    generated_text = llm_result[0]['generated_text']
                    # Clean up the output to only get the answer part
                    if "Answer:" in generated_text:
                        llm_answer = generated_text.split("Answer:")[1].strip()
                    else:
                        llm_answer = generated_text.replace(prompt, "").strip()
                except Exception as e:
                    print(f"LLM generation failed: {e}")
                    llm_answer = "LLM failed to generate an answer."
            else:
                llm_answer = "LLM not available."
        print(f"DEBUG: RAG pipeline\nQuestion: {query}\nContext used: {context[:500]}...\nQA Answer: {qa_answer}\nLLM Answer: {llm_answer}")
        answer = qa_answer if qa_answer else llm_answer
        return [{
            "answer": answer,
            "qa_answer": qa_answer,
            "llm_answer": llm_answer,
            "context": context,
            "chunks": results['documents'][0][:3],
            "matched_chunks": matched_chunks[:3]
        }]
