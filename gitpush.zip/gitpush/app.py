from flask import Flask, render_template, request, jsonify
from doc_vectorizer import DocVectorizer
import os

app = Flask(__name__)
vectorizer = DocVectorizer()
UPLOAD_FOLDER = 'uploads'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
def upload_file():
    if 'file' not in request.files:
        return jsonify({"error": "No file part"}), 400
    file = request.files['file']
    doc_type = request.form.get('doc_type')
    if file.filename == '':
        return jsonify({"error": "No selected file"}), 400
    filepath = os.path.join(app.config['UPLOAD_FOLDER'], file.filename)
    file.save(filepath)
    result = vectorizer.add_document(filepath, doc_type=doc_type)
    return jsonify({"message": f"File '{file.filename}' processed.", "result": result})

@app.route('/search', methods=['POST'])
def search():
    data = request.get_json()
    query = data.get('query', '')
    temperature = float(data.get('temperature', 0.1))
    topk = int(data.get('topk', 5))
    model_type = data.get('model_type', 'qa')
    doc_type = data.get('doc_type')
    if not query:
        return jsonify({"error": "No search query provided"}), 400
    results = vectorizer.search(query, n_results=topk, temperature=temperature, model_type=model_type, doc_type=doc_type)
    return jsonify(results)

@app.route('/clear_db', methods=['POST'])
def clear_db():
    vectorizer.clear_database()
    return jsonify({"message": "Vector database cleared."})

if __name__ == '__main__':
    app.run(debug=True, port=5050)
