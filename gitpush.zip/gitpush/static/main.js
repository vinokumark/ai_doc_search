$(function() {
    $('#upload-form').submit(function(e) {
        e.preventDefault();
        var formData = new FormData(this);
        $('#upload-status').text('Uploading...');
        $.ajax({
            url: '/upload',
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            success: function(data) {
                $('#upload-status').html('<span class="text-success">' + data.message + '</span>');
            },
            error: function(xhr) {
                $('#upload-status').html('<span class="text-danger">' + xhr.responseJSON.error + '</span>');
            }
        });
    });
    $('#clear-db-btn').click(function() {
        if (confirm('Are you sure you want to clear the vector database?')) {
            $.ajax({
                url: '/clear_db',
                type: 'POST',
                success: function(data) {
                    $('#upload-status').html('<span class="text-warning">' + data.message + '</span>');
                    $('#search-result').empty();
                    $('#rag-debug').empty();
                },
                error: function(xhr) {
                    $('#upload-status').html('<span class="text-danger">' + xhr.responseJSON.error + '</span>');
                }
            });
        }
    });
    $('#temperature').on('input', function() {
        $('#temp-value').text($(this).val());
    });
    $('#search-btn').click(function() {
        var query = $('#search-query').val();
        var temperature = parseFloat($('#temperature').val());
        var topk = parseInt($('#topk').val());
        var modelType = $('#model-type').val();
        var docType = $('#search-doc-type').val();
        $('#search-result').text('Searching...');
        $('#rag-debug').empty();
        $.ajax({
            url: '/search',
            type: 'POST',
            contentType: 'application/json',
            data: JSON.stringify({query: query, temperature: temperature, topk: topk, model_type: modelType, doc_type: docType}),
            success: function(data) {
                if (data.length > 0) {
                    let result = data[0];
                    let html = '<b>Answer:</b> ' + result.answer;
                    html += '<br><details><summary>Show Full Context Used</summary><pre>' + $('<div>').text(result.context).html() + '</pre></details>';
                    $('#search-result').html(html);
                    // RAG debug info
                    let debugHtml = '<div class="mt-2"><b>Top 3 Retrieved Chunks:</b>';
                    if (result.chunks && result.chunks.length > 0) {
                        debugHtml += '<ol>';
                        result.chunks.forEach(function(chunk, i) {
                            debugHtml += '<li><details><summary>Chunk ' + (i+1) + '</summary>';
                            debugHtml += '<pre>' + $('<div>').text(chunk).html().substring(0, 600) + '...</pre></details></li>';
                        });
                        debugHtml += '</ol>';
                    }
                    if (result.matched_chunks && result.matched_chunks.length > 0) {
                        debugHtml += '<b>Matched Chunks Used for Answer:</b><ol>';
                        result.matched_chunks.forEach(function(chunk, i) {
                            debugHtml += '<li><details><summary>Matched Chunk ' + (i+1) + '</summary>';
                            debugHtml += '<pre>' + $('<div>').text(chunk).html().substring(0, 600) + '...</pre></details></li>';
                        });
                        debugHtml += '</ol>';
                    }
                    debugHtml += '</div>';
                    $('#rag-debug').html(debugHtml);
                } else {
                    $('#search-result').html('<span class="text-danger">No answer found.</span>');
                    $('#rag-debug').empty();
                }
            },
            error: function(xhr) {
                $('#search-result').html('<span class="text-danger">' + xhr.responseJSON.error + '</span>');
                $('#rag-debug').empty();
            }
        });
    });
});
